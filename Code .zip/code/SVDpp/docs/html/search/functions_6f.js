var searchData=
[
  ['operator_2b_3d',['operator+=',['../classgather__type.html#a672f8aac3ab0b1bb48e857b77307f621',1,'gather_type']]]
];
