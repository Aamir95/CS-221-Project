var searchData=
[
  ['residual',['residual',['../structvertex__data.html#a89b8e42b50a16c7c49a1c76b5b319853',1,'vertex_data']]],
  ['rmse',['rmse',['../als_8hpp.html#a4a31cf557efa8c68c5c0a73a5405ba3f',1,'als.hpp']]],
  ['role',['role',['../structedge__data.html#a3fbba49eb9690a4fdeeda275d6c9cad9',1,'edge_data']]]
];
