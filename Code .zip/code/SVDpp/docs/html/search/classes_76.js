var searchData=
[
  ['vcallback',['VCallback',['../classgraphchi_1_1_v_callback.html',1,'graphchi']]],
  ['vcallback_3c_20latentvec_5ft_20_3e',['VCallback&lt; latentvec_t &gt;',['../classgraphchi_1_1_v_callback.html',1,'graphchi']]],
  ['vec',['vec',['../structvec.html',1,'']]],
  ['vertex_5fdata',['vertex_data',['../structvertex__data.html',1,'']]],
  ['vertex_5fdata_5fstore',['vertex_data_store',['../classgraphchi_1_1vertex__data__store.html',1,'graphchi']]],
  ['vertex_5fdegree',['vertex_degree',['../structgraphchi_1_1vertex__degree.html',1,'graphchi']]],
  ['vertex_5finfo',['vertex_info',['../structgraphchi_1_1vertex__info.html',1,'graphchi']]],
  ['vertex_5fvalue',['vertex_value',['../structgraphchi_1_1vertex__value.html',1,'graphchi']]],
  ['vertexdatachecker',['VertexDataChecker',['../class_vertex_data_checker.html',1,'']]]
];
