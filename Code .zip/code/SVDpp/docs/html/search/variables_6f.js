var searchData=
[
  ['obs',['obs',['../structedge__data.html#a1fc50f971f9fdbb4c9c90e33bda1c758',1,'edge_data']]]
];
