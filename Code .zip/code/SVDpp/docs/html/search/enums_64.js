var searchData=
[
  ['data_5frole_5ftype',['data_role_type',['../structedge__data.html#a058121c45cac9d350dd70939a023b55d',1,'edge_data']]]
];
