var searchData=
[
  ['data',['data',['../structgraphlab_1_1_graph_lab_vertex_wrapper.html#aa15502c3f0ca6fbfe636a25e1e349aa4',1,'graphlab::GraphLabVertexWrapper::data() const '],['../structgraphlab_1_1_graph_lab_vertex_wrapper.html#a3d93f69228ba4cea0de5b3aaf1af0800',1,'graphlab::GraphLabVertexWrapper::data()'],['../structgraphlab_1_1_graph_lab_edge_wrapper.html#a3bfdff77561dc08db04ea7cc3fc4d2c8',1,'graphlab::GraphLabEdgeWrapper::data() const '],['../structgraphlab_1_1_graph_lab_edge_wrapper.html#af3f688181c34dd970b0787479c9ab8d3',1,'graphlab::GraphLabEdgeWrapper::data()']]],
  ['data_5frole_5ftype',['data_role_type',['../structedge__data.html#a058121c45cac9d350dd70939a023b55d',1,'edge_data']]],
  ['de',['de',['../structde.html',1,'']]],
  ['degree',['degree',['../structgraphchi_1_1degree.html',1,'graphchi']]],
  ['degree_5fdata',['degree_data',['../classgraphchi_1_1degree__data.html#a2a1ca3bbc02cdf5effaa732b44817a4f',1,'graphchi::degree_data']]],
  ['degree_5fdata',['degree_data',['../classgraphchi_1_1degree__data.html',1,'graphchi']]],
  ['degree_5fdata_2ehpp',['degree_data.hpp',['../degree__data_8hpp.html',1,'']]],
  ['dense_5fadj',['dense_adj',['../structdense__adj.html',1,'']]],
  ['dense_5fbitset',['dense_bitset',['../classgraphchi_1_1dense__bitset.html',1,'graphchi']]],
  ['determine_5fnext_5fwindow',['determine_next_window',['../classgraphchi_1_1graphchi__dynamicgraph__engine.html#a9e9777b788639337052857935796380a',1,'graphchi::graphchi_dynamicgraph_engine::determine_next_window()'],['../classgraphchi_1_1graphchi__engine.html#aa020eb5cb9317f4a4e4e69e17c9846ba',1,'graphchi::graphchi_engine::determine_next_window()']]],
  ['determine_5fnumber_5fof_5fshards',['determine_number_of_shards',['../classgraphchi_1_1sharder.html#ab30874a25a6acd970085966ee2f12a3d',1,'graphchi::sharder']]],
  ['disable_5fpreloading',['disable_preloading',['../classgraphchi_1_1graphchi__dynamicgraph__engine.html#aa2a1875d67bb934b83ef9b2e762f573f',1,'graphchi::graphchi_dynamicgraph_engine']]],
  ['discover_5fshard_5fnum',['discover_shard_num',['../classgraphchi_1_1graphchi__engine.html#af5fba09baf9f293433ed1cfb90b28a06',1,'graphchi::graphchi_engine']]],
  ['distributed_5fgraph',['distributed_graph',['../structgraphlab_1_1distributed__graph.html',1,'graphlab']]],
  ['dynamic_5fgraph_5freader',['dynamic_graph_reader',['../streaming__pagerank_8cpp.html#a07cffb3d80a3b3a9f675df2f3a7f8fdd',1,'streaming_pagerank.cpp']]]
];
